document.addEventListener('DOMContentLoaded', () => {
    // 1. LOADER & AOS
    setTimeout(() => document.getElementById('loader').style.display = 'none', 1500);
    AOS.init({ duration: 1000, once: true, offset: 100 });

    // 2. THEME TOGGLE
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    const icon = themeToggle.querySelector('i');
    const savedTheme = localStorage.getItem('theme') || 'dark';
    html.setAttribute('data-theme', savedTheme);
    icon.className = savedTheme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
    themeToggle.addEventListener('click', () => {
        const current = html.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        icon.className = next === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
    });

    // 3. CUSTOM CURSOR & MAGNETIC BUTTONS
    if (window.matchMedia("(hover: hover)").matches) {
        const dot = document.getElementById('cursorDot');
        const outline = document.getElementById('cursorOutline');
        const glow = document.getElementById('mouseGlow');
        window.addEventListener('mousemove', (e) => {
            dot.style.left = `${e.clientX}px`; dot.style.top = `${e.clientY}px`;
            outline.animate({ left: `${e.clientX}px`, top: `${e.clientY}px` }, { duration: 500, fill: "forwards" });
            glow.style.left = `${e.clientX}px`; glow.style.top = `${e.clientY}px`; glow.style.opacity = '1';
        });
        document.querySelectorAll('a, button, .tilt').forEach(el => {
            el.addEventListener('mouseenter', () => outline.classList.add('hover'));
            el.addEventListener('mouseleave', () => outline.classList.remove('hover'));
        });

        // Magnetic Effect
        document.querySelectorAll('.magnetic').forEach(btn => {
            btn.addEventListener('mousemove', (e) => {
                const rect = btn.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                btn.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
            });
            btn.addEventListener('mouseleave', () => {
                btn.style.transform = 'translate(0, 0)';
            });
        });
    }

    // 4. PARTICLES
    const canvas = document.getElementById('particleCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
        resize(); window.addEventListener('resize', resize);
        const particles = Array.from({ length: 50 }, () => ({
            x: Math.random() * canvas.width, y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5, r: Math.random() * 2 + 1
        }));
        function draw() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const color = html.getAttribute('data-theme') === 'light' ? '128, 0, 32' : '212, 175, 55';
            particles.forEach(p => {
                p.x += p.vx; p.y += p.vy;
                if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
                if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
                ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${color}, 0.5)`; ctx.fill();
            });
            requestAnimationFrame(draw);
        }
        draw();
    }

    // 5. NAV & SCROLL
    const header = document.getElementById('header');
    const hamburger = document.getElementById('hamburger');
    const nav = document.getElementById('nav');
    const backToTop = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
        header.classList.toggle('scrolled', window.scrollY > 50);
        backToTop.classList.toggle('visible', window.scrollY > 500);
    });
    hamburger.addEventListener('click', () => { nav.classList.toggle('active'); hamburger.classList.toggle('active'); });
    document.querySelectorAll('.nav-list a').forEach(link => {
        link.addEventListener('click', () => {
            nav.classList.remove('active');
            document.querySelectorAll('.nav-list a').forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });
    backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

    // 6. COUNTERS & SKILLS
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                entry.target.querySelectorAll('.skill-progress').forEach(bar => { bar.style.width = bar.getAttribute('data-width') + '%'; });
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal, .skills-grid').forEach(el => observer.observe(el));

    const counterObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            document.querySelectorAll('.counter').forEach(counter => {
                const target = +counter.getAttribute('data-target');
                let count = 0;
                const update = () => {
                    count += target / 50;
                    if (count < target) { counter.innerText = Math.ceil(count); setTimeout(update, 30); }
                    else { counter.innerText = target; }
                };
                update();
            });
            counterObserver.disconnect();
        }
    }, { threshold: 0.5 });
    const stats = document.querySelector('.stats-container');
    if (stats) counterObserver.observe(stats);

    // 7. TYPING EFFECT
    const typingText = document.querySelector('.typing-text');
    const words = ['SEO', 'Shopify Stores', 'Branding', 'Web Design', 'AI Automation'];
    let wIndex = 0, cIndex = 0, isDeleting = false;
    function type() {
        const word = words[wIndex];
        typingText.textContent = isDeleting ? word.substring(0, cIndex--) : word.substring(0, cIndex++);
        let speed = isDeleting ? 50 : 100;
        if (!isDeleting && cIndex === word.length) { speed = 2000; isDeleting = true; }
        else if (isDeleting && cIndex === 0) { isDeleting = false; wIndex = (wIndex + 1) % words.length; speed = 500; }
        setTimeout(type, speed);
    }
    type();

    // 8. PORTFOLIO FILTER
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const filter = btn.getAttribute('data-filter');
            document.querySelectorAll('.portfolio-item').forEach(item => {
                if (filter === 'all' || item.getAttribute('data-cat') === filter) item.classList.remove('hide');
                else item.classList.add('hide');
            });
        });
    });

    // 9. CONTACT FORM -> WHATSAPP
    document.getElementById('contactForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('cName').value;
        const email = document.getElementById('cEmail').value;
        const phone = document.getElementById('cPhone').value;
        const msg = document.getElementById('cMsg').value;
        const text = `Hello ZM Creative!%0A%0AName: ${name}%0AEmail: ${email}%0APhone: ${phone}%0AMessage: ${msg}`;
        window.open(`https://wa.me/923289720331?text=${text}`, '_blank');
        e.target.reset();
    });

    // 10. LIVE VISITOR COUNTER
    const visitorCount = document.getElementById('visitorCount');
    let count = Math.floor(Math.random() * 100) + 100;
    setInterval(() => {
        count += Math.floor(Math.random() * 5) - 2;
        if(count < 100) count = 100;
        visitorCount.textContent = count;
    }, 3000);

    // 11. CHATBOT & POPUPS
    const chatWindow = document.getElementById('chatWindow');
    document.getElementById('chatToggle').addEventListener('click', () => chatWindow.classList.toggle('open'));
    document.getElementById('chatClose').addEventListener('click', () => chatWindow.classList.remove('open'));

    const newsletterOverlay = document.getElementById('newsletterOverlay');
    if (!sessionStorage.getItem('newsletterShown')) {
        setTimeout(() => {
            newsletterOverlay.classList.add('show');
            sessionStorage.setItem('newsletterShown', 'true');
        }, 10000); // Shows after 10 seconds
    }
    document.getElementById('popupClose').addEventListener('click', () => newsletterOverlay.classList.remove('show'));
    newsletterOverlay.addEventListener('click', (e) => { if (e.target === newsletterOverlay) newsletterOverlay.classList.remove('show'); });

    const cookie = document.getElementById('cookie');
    if (!localStorage.getItem('cookie')) setTimeout(() => cookie.classList.add('show'), 3000);
    document.getElementById('cookieAccept').addEventListener('click', () => { localStorage.setItem('cookie', 'true'); cookie.classList.remove('show'); });

    // 12. 3D TILT EFFECT
    document.querySelectorAll('.tilt').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left; const y = e.clientY - rect.top;
            const centerX = rect.width / 2; const centerY = rect.height / 2;
            const rotateX = ((y - centerY) / centerY) * -5; const rotateY = ((x - centerX) / centerX) * 5;
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });
        card.addEventListener('mouseleave', () => { card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)'; });
    });
});